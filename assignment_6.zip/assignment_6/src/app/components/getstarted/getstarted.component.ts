import { Component } from '@angular/core';

@Component({
  selector: 'app-getstarted',
  standalone: true,
  imports: [],
  templateUrl: './getstarted.component.html',
  styleUrl: './getstarted.component.css'
})
export class GetstartedComponent {

}
