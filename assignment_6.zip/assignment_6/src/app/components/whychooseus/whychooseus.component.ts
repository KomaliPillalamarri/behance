import { Component } from '@angular/core';
import { NgFor } from '@angular/common';

@Component({
  selector: 'app-whychooseus',
  standalone: true,
  templateUrl: './whychooseus.component.html',
  styleUrl: './whychooseus.component.css',
  imports: [NgFor]
})
export class WhychooseusComponent {

}
